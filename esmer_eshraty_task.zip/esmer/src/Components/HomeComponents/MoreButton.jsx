import React from 'react'

function MoreButton() {
  return (
    <div className='pop'>
      <button className="more">Daha çox</button>

    </div>
  )
}

export default MoreButton
