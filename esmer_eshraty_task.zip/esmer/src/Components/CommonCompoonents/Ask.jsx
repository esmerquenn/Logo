import React from "react";

function Ask() {
  return (
    <div className="ask">
      <h5 className="h5">Suallar</h5>
      <ul>
        <li>10 sual- Azərbaycan dili</li>
        <li>10 sual-Riyaziyyat</li>
      </ul>
    </div>
  );
}

export default Ask;
