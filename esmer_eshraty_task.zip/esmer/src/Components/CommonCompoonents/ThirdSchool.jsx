import React from "react";

function ThirdSchool({name}) {
  return <p className="p"> {name}</p>;
}

export default ThirdSchool;
