import React from "react";
function Second({icon, title}) {
  return (
    <div className="left">
      {icon}<b>{title}</b>
    </div>
  );
}

export default Second;
