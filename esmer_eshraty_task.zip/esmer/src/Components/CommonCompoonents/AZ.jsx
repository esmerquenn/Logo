import React from "react";
import { FaAngleDown } from "react-icons/fa6";
function AZ() {
  return (
    <div className="slct_li">
      <select name="" id="">
        <option value="">AZ</option>
        <option value="">RU</option>
        <option value="">EN</option>
      </select>
      <FaAngleDown className="fa-angle-down" />
    </div>
  );
}

export default AZ;
