import React from 'react'

function ExamHead() {
  return (
    <header className="exam container">
    <div className="content">
      <div className="exam-left">
        <h1 className="txtwhite">3-cü sinif imtahanı</h1>
        <ul className="txtwhite">
          <li>• Lorem Ipsum is simply dummy text of the printing and typesetting</li>
          <li>• Lorem Ipsum is simply dummy text of the printing and typesetting</li>
        </ul>
      </div>
      <button className="exam_btn">1 Azn-imtahanı al</button>
      <div className="img"></div>
    </div>
  </header>
  )
}

export default ExamHead
