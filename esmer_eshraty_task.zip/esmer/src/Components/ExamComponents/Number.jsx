import React from 'react'
import { BiSolidMessageDots } from 'react-icons/bi'

function Number() {
  return (
    <div className="number">
    <span className="num">4.9</span>
    <span className="num2">
      <BiSolidMessageDots />
      440 rəy
    </span>
  </div>
  )
}

export default Number
